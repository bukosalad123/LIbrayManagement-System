import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, date, timestamp, uuid } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Students table
export const students = pgTable("students", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  studentId: varchar("student_id", { length: 20 }).notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Authors table
export const authors = pgTable("authors", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Book categories table
export const bookCategories = pgTable("book_categories", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  description: text("description").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Librarian types table
export const librarianTypes = pgTable("librarian_types", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  description: text("description"),
});

// Librarians table
export const librarians = pgTable("librarians", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  typeId: uuid("type_id").references(() => librarianTypes.id).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Books table
export const books = pgTable("books", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  bookId: varchar("book_id", { length: 20 }).notNull().unique(),
  title: text("title").notNull(),
  authorId: uuid("author_id").references(() => authors.id).notNull(),
  publisher: text("publisher").notNull(),
  edition: text("edition"),
  isbn: varchar("isbn", { length: 17 }).notNull().unique(),
  categoryId: uuid("category_id").references(() => bookCategories.id).notNull(),
  status: varchar("status", { length: 20 }).notNull().default("available"), // available, borrowed, maintenance
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Borrowed books table
export const borrowedBooks = pgTable("borrowed_books", {
  id: uuid("id").primaryKey().default(sql`gen_random_uuid()`),
  bookId: uuid("book_id").references(() => books.id).notNull(),
  studentId: uuid("student_id").references(() => students.id).notNull(),
  librarianId: uuid("librarian_id").references(() => librarians.id).notNull(),
  dateBorrowed: date("date_borrowed").notNull(),
  dueDate: date("due_date").notNull(),
  dateReturned: date("date_returned"),
  condition: text("condition").default("good"), // good, fair, damaged, lost
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const studentsRelations = relations(students, ({ many }) => ({
  borrowedBooks: many(borrowedBooks),
}));

export const authorsRelations = relations(authors, ({ many }) => ({
  books: many(books),
}));

export const bookCategoriesRelations = relations(bookCategories, ({ many }) => ({
  books: many(books),
}));

export const librarianTypesRelations = relations(librarianTypes, ({ many }) => ({
  librarians: many(librarians),
}));

export const librariansRelations = relations(librarians, ({ one, many }) => ({
  type: one(librarianTypes, {
    fields: [librarians.typeId],
    references: [librarianTypes.id],
  }),
  borrowedBooks: many(borrowedBooks),
}));

export const booksRelations = relations(books, ({ one, many }) => ({
  author: one(authors, {
    fields: [books.authorId],
    references: [authors.id],
  }),
  category: one(bookCategories, {
    fields: [books.categoryId],
    references: [bookCategories.id],
  }),
  borrowedBooks: many(borrowedBooks),
}));

export const borrowedBooksRelations = relations(borrowedBooks, ({ one }) => ({
  book: one(books, {
    fields: [borrowedBooks.bookId],
    references: [books.id],
  }),
  student: one(students, {
    fields: [borrowedBooks.studentId],
    references: [students.id],
  }),
  librarian: one(librarians, {
    fields: [borrowedBooks.librarianId],
    references: [librarians.id],
  }),
}));

// Insert schemas
export const insertStudentSchema = createInsertSchema(students).omit({
  id: true,
  createdAt: true,
});

export const insertAuthorSchema = createInsertSchema(authors).omit({
  id: true,
  createdAt: true,
});

export const insertBookCategorySchema = createInsertSchema(bookCategories).omit({
  id: true,
  createdAt: true,
});

export const insertLibrarianTypeSchema = createInsertSchema(librarianTypes).omit({
  id: true,
});

export const insertLibrarianSchema = createInsertSchema(librarians).omit({
  id: true,
  createdAt: true,
});

export const insertBookSchema = createInsertSchema(books).omit({
  id: true,
  createdAt: true,
});

export const insertBorrowedBookSchema = createInsertSchema(borrowedBooks).omit({
  id: true,
  createdAt: true,
});

// Types
export type Student = typeof students.$inferSelect;
export type InsertStudent = z.infer<typeof insertStudentSchema>;

export type Author = typeof authors.$inferSelect;
export type InsertAuthor = z.infer<typeof insertAuthorSchema>;

export type BookCategory = typeof bookCategories.$inferSelect;
export type InsertBookCategory = z.infer<typeof insertBookCategorySchema>;

export type LibrarianType = typeof librarianTypes.$inferSelect;
export type InsertLibrarianType = z.infer<typeof insertLibrarianTypeSchema>;

export type Librarian = typeof librarians.$inferSelect;
export type InsertLibrarian = z.infer<typeof insertLibrarianSchema>;

export type Book = typeof books.$inferSelect;
export type InsertBook = z.infer<typeof insertBookSchema>;

export type BorrowedBook = typeof borrowedBooks.$inferSelect;
export type InsertBorrowedBook = z.infer<typeof insertBorrowedBookSchema>;

// Extended types with relations
export type BookWithRelations = Book & {
  author: Author;
  category: BookCategory;
};

export type BorrowedBookWithRelations = BorrowedBook & {
  book: BookWithRelations;
  student: Student;
  librarian: Librarian & { type: LibrarianType };
};

export type LibrarianWithType = Librarian & {
  type: LibrarianType;
};
