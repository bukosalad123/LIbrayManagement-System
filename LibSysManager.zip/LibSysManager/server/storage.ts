
import { db } from "./db";
import { 
  students, 
  authors, 
  bookCategories, 
  librarianTypes, 
  librarians, 
  books, 
  borrowedBooks,
  type InsertStudent,
  type InsertAuthor,
  type InsertBookCategory,
  type InsertLibrarianType,
  type InsertLibrarian,
  type InsertBook,
  type InsertBorrowedBook
} from "@shared/schema";
import { eq, sql, desc } from "drizzle-orm";
import { nanoid } from "nanoid";

class Storage {
  // Dashboard stats
  async getDashboardStats() {
    const [totalStudents] = await db.select({ count: sql<number>`count(*)` }).from(students);
    const [totalBooks] = await db.select({ count: sql<number>`count(*)` }).from(books);
    const [totalAuthors] = await db.select({ count: sql<number>`count(*)` }).from(authors);
    const [borrowedCount] = await db.select({ count: sql<number>`count(*)` }).from(borrowedBooks).where(eq(borrowedBooks.dateReturned, null));
    
    return {
      totalStudents: totalStudents.count,
      totalBooks: totalBooks.count,
      totalAuthors: totalAuthors.count,
      borrowedBooks: borrowedCount.count,
    };
  }

  // Students
  async getStudents() {
    return await db.select().from(students).orderBy(desc(students.createdAt));
  }

  async getStudent(id: string) {
    const [student] = await db.select().from(students).where(eq(students.id, id));
    return student;
  }

  async createStudent(data: InsertStudent) {
    const [student] = await db.insert(students).values({
      ...data,
      id: nanoid(),
    }).returning();
    return student;
  }

  async updateStudent(id: string, data: Partial<InsertStudent>) {
    const [student] = await db.update(students).set(data).where(eq(students.id, id)).returning();
    return student;
  }

  async deleteStudent(id: string) {
    await db.delete(students).where(eq(students.id, id));
  }

  // Authors
  async getAuthors() {
    return await db.select().from(authors).orderBy(desc(authors.createdAt));
  }

  async getAuthor(id: string) {
    const [author] = await db.select().from(authors).where(eq(authors.id, id));
    return author;
  }

  async createAuthor(data: InsertAuthor) {
    const [author] = await db.insert(authors).values({
      ...data,
      id: nanoid(),
    }).returning();
    return author;
  }

  async updateAuthor(id: string, data: Partial<InsertAuthor>) {
    const [author] = await db.update(authors).set(data).where(eq(authors.id, id)).returning();
    return author;
  }

  async deleteAuthor(id: string) {
    await db.delete(authors).where(eq(authors.id, id));
  }

  // Book Categories
  async getBookCategories() {
    return await db.select().from(bookCategories).orderBy(desc(bookCategories.createdAt));
  }

  async getBookCategory(id: string) {
    const [category] = await db.select().from(bookCategories).where(eq(bookCategories.id, id));
    return category;
  }

  async createBookCategory(data: InsertBookCategory) {
    const [category] = await db.insert(bookCategories).values({
      ...data,
      id: nanoid(),
    }).returning();
    return category;
  }

  async updateBookCategory(id: string, data: Partial<InsertBookCategory>) {
    const [category] = await db.update(bookCategories).set(data).where(eq(bookCategories.id, id)).returning();
    return category;
  }

  async deleteBookCategory(id: string) {
    await db.delete(bookCategories).where(eq(bookCategories.id, id));
  }

  // Librarian Types
  async getLibrarianTypes() {
    return await db.select().from(librarianTypes);
  }

  async createLibrarianType(data: InsertLibrarianType) {
    const [type] = await db.insert(librarianTypes).values({
      ...data,
      id: nanoid(),
    }).returning();
    return type;
  }

  // Librarians
  async getLibrarians() {
    return await db.select({
      id: librarians.id,
      name: librarians.name,
      email: librarians.email,
      typeId: librarians.typeId,
      createdAt: librarians.createdAt,
      type: {
        id: librarianTypes.id,
        name: librarianTypes.name,
        description: librarianTypes.description,
      }
    }).from(librarians)
      .leftJoin(librarianTypes, eq(librarians.typeId, librarianTypes.id))
      .orderBy(desc(librarians.createdAt));
  }

  async getLibrarian(id: string) {
    const [librarian] = await db.select({
      id: librarians.id,
      name: librarians.name,
      email: librarians.email,
      typeId: librarians.typeId,
      createdAt: librarians.createdAt,
      type: {
        id: librarianTypes.id,
        name: librarianTypes.name,
        description: librarianTypes.description,
      }
    }).from(librarians)
      .leftJoin(librarianTypes, eq(librarians.typeId, librarianTypes.id))
      .where(eq(librarians.id, id));
    return librarian;
  }

  async createLibrarian(data: InsertLibrarian) {
    const [librarian] = await db.insert(librarians).values({
      ...data,
      id: nanoid(),
    }).returning();
    return librarian;
  }

  async updateLibrarian(id: string, data: Partial<InsertLibrarian>) {
    const [librarian] = await db.update(librarians).set(data).where(eq(librarians.id, id)).returning();
    return librarian;
  }

  async deleteLibrarian(id: string) {
    await db.delete(librarians).where(eq(librarians.id, id));
  }

  // Books
  async getBooks() {
    return await db.select({
      id: books.id,
      bookId: books.bookId,
      title: books.title,
      authorId: books.authorId,
      publisher: books.publisher,
      edition: books.edition,
      isbn: books.isbn,
      categoryId: books.categoryId,
      status: books.status,
      createdAt: books.createdAt,
      author: {
        id: authors.id,
        name: authors.name,
        email: authors.email,
      },
      category: {
        id: bookCategories.id,
        description: bookCategories.description,
      }
    }).from(books)
      .leftJoin(authors, eq(books.authorId, authors.id))
      .leftJoin(bookCategories, eq(books.categoryId, bookCategories.id))
      .orderBy(desc(books.createdAt));
  }

  async getBook(id: string) {
    const [book] = await db.select({
      id: books.id,
      bookId: books.bookId,
      title: books.title,
      authorId: books.authorId,
      publisher: books.publisher,
      edition: books.edition,
      isbn: books.isbn,
      categoryId: books.categoryId,
      status: books.status,
      createdAt: books.createdAt,
      author: {
        id: authors.id,
        name: authors.name,
        email: authors.email,
      },
      category: {
        id: bookCategories.id,
        description: bookCategories.description,
      }
    }).from(books)
      .leftJoin(authors, eq(books.authorId, authors.id))
      .leftJoin(bookCategories, eq(books.categoryId, bookCategories.id))
      .where(eq(books.id, id));
    return book;
  }

  async createBook(data: InsertBook) {
    const [book] = await db.insert(books).values({
      ...data,
      id: nanoid(),
    }).returning();
    return book;
  }

  async updateBook(id: string, data: Partial<InsertBook>) {
    const [book] = await db.update(books).set(data).where(eq(books.id, id)).returning();
    return book;
  }

  async deleteBook(id: string) {
    await db.delete(books).where(eq(books.id, id));
  }

  // Borrowed Books
  async getBorrowedBooks() {
    return await db.select({
      id: borrowedBooks.id,
      bookId: borrowedBooks.bookId,
      studentId: borrowedBooks.studentId,
      librarianId: borrowedBooks.librarianId,
      dateBorrowed: borrowedBooks.dateBorrowed,
      dueDate: borrowedBooks.dueDate,
      dateReturned: borrowedBooks.dateReturned,
      condition: borrowedBooks.condition,
      notes: borrowedBooks.notes,
      createdAt: borrowedBooks.createdAt,
      book: {
        id: books.id,
        title: books.title,
        bookId: books.bookId,
        author: {
          name: authors.name,
        }
      },
      student: {
        id: students.id,
        name: students.name,
        studentId: students.studentId,
      },
      librarian: {
        id: librarians.id,
        name: librarians.name,
      }
    }).from(borrowedBooks)
      .leftJoin(books, eq(borrowedBooks.bookId, books.id))
      .leftJoin(authors, eq(books.authorId, authors.id))
      .leftJoin(students, eq(borrowedBooks.studentId, students.id))
      .leftJoin(librarians, eq(borrowedBooks.librarianId, librarians.id))
      .orderBy(desc(borrowedBooks.createdAt));
  }

  async getBorrowedBook(id: string) {
    const [borrowedBook] = await db.select().from(borrowedBooks).where(eq(borrowedBooks.id, id));
    return borrowedBook;
  }

  async createBorrowedBook(data: InsertBorrowedBook) {
    const [borrowedBook] = await db.insert(borrowedBooks).values({
      ...data,
      id: nanoid(),
    }).returning();
    
    // Update book status to borrowed
    await db.update(books).set({ status: "borrowed" }).where(eq(books.id, data.bookId));
    
    return borrowedBook;
  }

  async returnBook(id: string, dateReturned: string, condition?: string, notes?: string) {
    const [borrowedBook] = await db.update(borrowedBooks)
      .set({ 
        dateReturned, 
        condition: condition || "good", 
        notes 
      })
      .where(eq(borrowedBooks.id, id))
      .returning();

    // Update book status back to available
    if (borrowedBook) {
      await db.update(books).set({ status: "available" }).where(eq(books.id, borrowedBook.bookId));
    }

    return borrowedBook;
  }
}

export const storage = new Storage();
