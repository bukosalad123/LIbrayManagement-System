import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertStudentSchema,
  insertAuthorSchema,
  insertBookCategorySchema,
  insertLibrarianTypeSchema,
  insertLibrarianSchema,
  insertBookSchema,
  insertBorrowedBookSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  // Students routes
  app.get("/api/students", async (req, res) => {
    try {
      const students = await storage.getStudents();
      res.json(students);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", async (req, res) => {
    try {
      const student = await storage.getStudent(req.params.id);
      if (!student) {
        return res.status(404).json({ message: "Student not found" });
      }
      res.json(student);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch student" });
    }
  });

  app.post("/api/students", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.parse(req.body);
      const student = await storage.createStudent(validatedData);
      res.status(201).json(student);
    } catch (error) {
      res.status(400).json({ message: "Invalid student data" });
    }
  });

  app.put("/api/students/:id", async (req, res) => {
    try {
      const validatedData = insertStudentSchema.partial().parse(req.body);
      const student = await storage.updateStudent(req.params.id, validatedData);
      res.json(student);
    } catch (error) {
      res.status(400).json({ message: "Invalid student data" });
    }
  });

  app.delete("/api/students/:id", async (req, res) => {
    try {
      await storage.deleteStudent(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete student" });
    }
  });

  // Authors routes
  app.get("/api/authors", async (req, res) => {
    try {
      const authors = await storage.getAuthors();
      res.json(authors);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch authors" });
    }
  });

  app.get("/api/authors/:id", async (req, res) => {
    try {
      const author = await storage.getAuthor(req.params.id);
      if (!author) {
        return res.status(404).json({ message: "Author not found" });
      }
      res.json(author);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch author" });
    }
  });

  app.post("/api/authors", async (req, res) => {
    try {
      const validatedData = insertAuthorSchema.parse(req.body);
      const author = await storage.createAuthor(validatedData);
      res.status(201).json(author);
    } catch (error) {
      res.status(400).json({ message: "Invalid author data" });
    }
  });

  app.put("/api/authors/:id", async (req, res) => {
    try {
      const validatedData = insertAuthorSchema.partial().parse(req.body);
      const author = await storage.updateAuthor(req.params.id, validatedData);
      res.json(author);
    } catch (error) {
      res.status(400).json({ message: "Invalid author data" });
    }
  });

  app.delete("/api/authors/:id", async (req, res) => {
    try {
      await storage.deleteAuthor(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete author" });
    }
  });

  // Book Categories routes
  app.get("/api/categories", async (req, res) => {
    try {
      const categories = await storage.getBookCategories();
      res.json(categories);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.get("/api/categories/:id", async (req, res) => {
    try {
      const category = await storage.getBookCategory(req.params.id);
      if (!category) {
        return res.status(404).json({ message: "Category not found" });
      }
      res.json(category);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch category" });
    }
  });

  app.post("/api/categories", async (req, res) => {
    try {
      const validatedData = insertBookCategorySchema.parse(req.body);
      const category = await storage.createBookCategory(validatedData);
      res.status(201).json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid category data" });
    }
  });

  app.put("/api/categories/:id", async (req, res) => {
    try {
      const validatedData = insertBookCategorySchema.partial().parse(req.body);
      const category = await storage.updateBookCategory(req.params.id, validatedData);
      res.json(category);
    } catch (error) {
      res.status(400).json({ message: "Invalid category data" });
    }
  });

  app.delete("/api/categories/:id", async (req, res) => {
    try {
      await storage.deleteBookCategory(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete category" });
    }
  });

  // Librarian Types routes
  app.get("/api/librarian-types", async (req, res) => {
    try {
      const types = await storage.getLibrarianTypes();
      res.json(types);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch librarian types" });
    }
  });

  app.post("/api/librarian-types", async (req, res) => {
    try {
      const validatedData = insertLibrarianTypeSchema.parse(req.body);
      const type = await storage.createLibrarianType(validatedData);
      res.status(201).json(type);
    } catch (error) {
      res.status(400).json({ message: "Invalid librarian type data" });
    }
  });

  // Librarians routes
  app.get("/api/librarians", async (req, res) => {
    try {
      const librarians = await storage.getLibrarians();
      res.json(librarians);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch librarians" });
    }
  });

  app.get("/api/librarians/:id", async (req, res) => {
    try {
      const librarian = await storage.getLibrarian(req.params.id);
      if (!librarian) {
        return res.status(404).json({ message: "Librarian not found" });
      }
      res.json(librarian);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch librarian" });
    }
  });

  app.post("/api/librarians", async (req, res) => {
    try {
      const validatedData = insertLibrarianSchema.parse(req.body);
      const librarian = await storage.createLibrarian(validatedData);
      res.status(201).json(librarian);
    } catch (error) {
      res.status(400).json({ message: "Invalid librarian data" });
    }
  });

  app.put("/api/librarians/:id", async (req, res) => {
    try {
      const validatedData = insertLibrarianSchema.partial().parse(req.body);
      const librarian = await storage.updateLibrarian(req.params.id, validatedData);
      res.json(librarian);
    } catch (error) {
      res.status(400).json({ message: "Invalid librarian data" });
    }
  });

  app.delete("/api/librarians/:id", async (req, res) => {
    try {
      await storage.deleteLibrarian(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete librarian" });
    }
  });

  // Books routes
  app.get("/api/books", async (req, res) => {
    try {
      const books = await storage.getBooks();
      res.json(books);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.get("/api/books/:id", async (req, res) => {
    try {
      const book = await storage.getBook(req.params.id);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.json(book);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  app.post("/api/books", async (req, res) => {
    try {
      const validatedData = insertBookSchema.parse(req.body);
      const book = await storage.createBook(validatedData);
      res.status(201).json(book);
    } catch (error) {
      res.status(400).json({ message: "Invalid book data" });
    }
  });

  app.put("/api/books/:id", async (req, res) => {
    try {
      const validatedData = insertBookSchema.partial().parse(req.body);
      const book = await storage.updateBook(req.params.id, validatedData);
      res.json(book);
    } catch (error) {
      res.status(400).json({ message: "Invalid book data" });
    }
  });

  app.delete("/api/books/:id", async (req, res) => {
    try {
      await storage.deleteBook(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete book" });
    }
  });

  // Borrowed Books routes
  app.get("/api/borrowed-books", async (req, res) => {
    try {
      const borrowedBooks = await storage.getBorrowedBooks();
      res.json(borrowedBooks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch borrowed books" });
    }
  });

  app.get("/api/borrowed-books/:id", async (req, res) => {
    try {
      const borrowedBook = await storage.getBorrowedBook(req.params.id);
      if (!borrowedBook) {
        return res.status(404).json({ message: "Borrowed book record not found" });
      }
      res.json(borrowedBook);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch borrowed book" });
    }
  });

  app.post("/api/borrowed-books", async (req, res) => {
    try {
      const validatedData = insertBorrowedBookSchema.parse(req.body);
      const borrowedBook = await storage.createBorrowedBook(validatedData);
      res.status(201).json(borrowedBook);
    } catch (error) {
      res.status(400).json({ message: "Invalid borrowed book data" });
    }
  });

  app.put("/api/borrowed-books/:id/return", async (req, res) => {
    try {
      const { dateReturned, condition, notes } = req.body;
      const borrowedBook = await storage.returnBook(req.params.id, dateReturned, condition, notes);
      res.json(borrowedBook);
    } catch (error) {
      res.status(400).json({ message: "Failed to return book" });
    }
  });

  // Weather API proxy
  app.get("/api/weather", async (req, res) => {
    try {
      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ message: "Weather API key not configured" });
      }

      const { lat = "40.7128", lon = "-74.0060" } = req.query; // Default to NYC
      const weatherUrl = `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`;
      
      const response = await fetch(weatherUrl);
      if (!response.ok) {
        throw new Error("Weather API request failed");
      }
      
      const weatherData = await response.json();
      res.json(weatherData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch weather data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
