
import { db } from "./db";
import { 
  students, 
  authors, 
  bookCategories, 
  librarianTypes, 
  librarians, 
  books, 
  borrowedBooks
} from "@shared/schema";

async function clearAllData() {
  try {
    console.log("Clearing all data from database...");
    
    // Delete in correct order to respect foreign key constraints
    await db.delete(borrowedBooks);
    console.log("✓ Cleared borrowed books");
    
    await db.delete(books);
    console.log("✓ Cleared books");
    
    await db.delete(librarians);
    console.log("✓ Cleared librarians");
    
    await db.delete(librarianTypes);
    console.log("✓ Cleared librarian types");
    
    await db.delete(bookCategories);
    console.log("✓ Cleared book categories");
    
    await db.delete(authors);
    console.log("✓ Cleared authors");
    
    await db.delete(students);
    console.log("✓ Cleared students");
    
    console.log("✅ All template data cleared successfully!");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error clearing data:", error);
    process.exit(1);
  }
}

clearAllData();
