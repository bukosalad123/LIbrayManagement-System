import { Link, useLocation } from "wouter";
import { useState, useEffect } from "react";
import { 
  BookOpen, 
  LayoutDashboard, 
  Users, 
  Book, 
  PenTool, 
  Tags, 
  RefreshCw, 
  Bus,
  ChevronLeft,
  ChevronRight,
  Sun,
  Moon
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";

const navigationItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/students", label: "Students", icon: Users },
  { href: "/books", label: "Books", icon: Book },
  { href: "/authors", label: "Authors", icon: PenTool },
  { href: "/categories", label: "Categories", icon: Tags },
  { href: "/borrow-return", label: "Borrow/Return", icon: RefreshCw },
  { href: "/librarians", label: "Librarians", icon: Bus },
];

export default function Sidebar() {
  const [location] = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    // Check if dark mode is saved in localStorage or system preference
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('darkMode');
      if (saved !== null) {
        return JSON.parse(saved);
      }
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  useEffect(() => {
    // Apply dark mode class to document
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    // Save preference to localStorage
    localStorage.setItem('darkMode', JSON.stringify(isDarkMode));
  }, [isDarkMode]);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
  };

  return (
    <aside className={cn(
      "bg-card border-r border-border flex-shrink-0 flex flex-col transition-all duration-300",
      isCollapsed ? "w-16" : "w-64"
    )}>
      <div className={cn(
        "border-b border-border flex items-center justify-between",
        isCollapsed ? "p-3" : "p-6"
      )}>
        <div className={cn("flex items-center", isCollapsed && "hidden")}>
          <h1 className="text-xl font-bold text-primary flex items-center" data-testid="app-title">
            <BookOpen className="mr-2 h-5 w-5" />
            LibSys
          </h1>
        </div>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setIsCollapsed(!isCollapsed)}
          className={cn("h-8 w-8", isCollapsed && "mx-auto")}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4" />
          ) : (
            <ChevronLeft className="h-4 w-4" />
          )}
        </Button>
      </div>
      {!isCollapsed && (
        <div className="px-6 pb-2">
          <p className="text-sm text-muted-foreground">Library Management</p>
        </div>
      )}
      
      <nav className="flex-1 p-4">
        <ul className="space-y-2">
          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href || (item.href === "/dashboard" && location === "/");
            
            return (
              <li key={item.href}>
                <Link 
                  href={item.href}
                  data-testid={`nav-${item.label.toLowerCase().replace(/[^a-z0-9]/g, '-')}`}
                  className={cn(
                    "flex items-center text-sm font-medium rounded-lg transition-colors",
                    isCollapsed ? "px-2 py-3 justify-center" : "px-4 py-3",
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : "hover:bg-accent hover:text-accent-foreground"
                  )}
                  title={isCollapsed ? item.label : undefined}
                >
                  <Icon className={cn("h-4 w-4", !isCollapsed && "mr-3")} />
                  {!isCollapsed && item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
      
      <div className="p-4 border-t border-border space-y-4">
        {/* Dark Mode Toggle */}
        <div className={cn(
          "flex items-center",
          isCollapsed ? "justify-center" : "justify-between"
        )}>
          {!isCollapsed && (
            <div className="flex items-center space-x-2">
              <Sun className="h-4 w-4" />
              <span className="text-sm">Dark Mode</span>
              <Moon className="h-4 w-4" />
            </div>
          )}
          <Switch 
            checked={isDarkMode}
            onCheckedChange={toggleDarkMode}
            className={cn(isCollapsed && "mx-auto")}
          />
        </div>

        {/* User Info */}
        <div className={cn(
          "flex items-center",
          isCollapsed ? "justify-center" : "space-x-3"
        )}>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <Bus className="text-primary-foreground h-4 w-4" />
          </div>
          {!isCollapsed && (
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium" data-testid="user-name">Admin User</p>
              <p className="text-xs text-muted-foreground truncate" data-testid="user-email">admin@libsys.com</p>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
