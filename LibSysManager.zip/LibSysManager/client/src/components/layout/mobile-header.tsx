import { Menu, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  Book, 
  PenTool, 
  Tags, 
  RefreshCw, 
  Bus 
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigationItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/students", label: "Students", icon: Users },
  { href: "/books", label: "Books", icon: Book },
  { href: "/authors", label: "Authors", icon: PenTool },
  { href: "/categories", label: "Categories", icon: Tags },
  { href: "/borrow-return", label: "Borrow/Return", icon: RefreshCw },
  { href: "/librarians", label: "Librarians", icon: Bus },
];

export default function MobileHeader() {
  const [location] = useLocation();

  return (
    <div className="bg-card border-b border-border p-4 flex items-center justify-between">
      <h1 className="text-lg font-bold text-primary flex items-center" data-testid="mobile-app-title">
        <BookOpen className="mr-2 h-5 w-5" />
        LibSys
      </h1>
      
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" data-testid="mobile-menu-trigger">
            <Menu className="h-5 w-5" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-64 p-0">
          <div className="p-6 border-b border-border">
            <h1 className="text-xl font-bold text-primary flex items-center">
              <BookOpen className="mr-2 h-5 w-5" />
              LibSys
            </h1>
            <p className="text-sm text-muted-foreground mt-1">Library Management</p>
          </div>
          
          <nav className="p-4">
            <ul className="space-y-2">
              {navigationItems.map((item) => {
                const Icon = item.icon;
                const isActive = location === item.href || (item.href === "/dashboard" && location === "/");
                
                return (
                  <li key={item.href}>
                    <Link 
                      href={item.href}
                      className={cn(
                        "flex items-center px-4 py-3 text-sm font-medium rounded-lg transition-colors",
                        isActive 
                          ? "bg-primary text-primary-foreground" 
                          : "hover:bg-accent hover:text-accent-foreground"
                      )}
                    >
                      <Icon className="mr-3 h-4 w-4" />
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
        </SheetContent>
      </Sheet>
    </div>
  );
}
