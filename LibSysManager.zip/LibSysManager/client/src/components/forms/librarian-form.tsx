import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertLibrarianSchema, type LibrarianWithType, type InsertLibrarian, type LibrarianType } from "@shared/schema";

interface LibrarianFormProps {
  librarian?: LibrarianWithType | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function LibrarianForm({ librarian, onSuccess, onCancel }: LibrarianFormProps) {
  const { toast } = useToast();
  const isEditing = !!librarian;

  const { data: librarianTypes } = useQuery<LibrarianType[]>({
    queryKey: ["/api/librarian-types"],
  });

  const form = useForm<InsertLibrarian>({
    resolver: zodResolver(insertLibrarianSchema),
    defaultValues: {
      name: librarian?.name || "",
      email: librarian?.email || "",
      typeId: librarian?.typeId || "",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertLibrarian) => apiRequest("POST", "/api/librarians", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/librarians"] });
      toast({ title: "Success", description: "Librarian created successfully" });
      onSuccess();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create librarian", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertLibrarian) => 
      apiRequest("PUT", `/api/librarians/${librarian!.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/librarians"] });
      toast({ title: "Success", description: "Librarian updated successfully" });
      onSuccess();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update librarian", variant: "destructive" });
    },
  });

  const onSubmit = (data: InsertLibrarian) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleClearForm = () => {
    form.reset({
      name: "",
      email: "",
      typeId: "",
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter librarian name" {...field} data-testid="input-librarian-name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl>
                <Input type="email" placeholder="Enter email address" {...field} data-testid="input-librarian-email" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="typeId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Type</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-librarian-type">
                    <SelectValue placeholder="Select librarian type" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {librarianTypes?.map((type) => (
                    <SelectItem key={type.id} value={type.id}>
                      {type.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3">
          <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel">
            Cancel
          </Button>
          <Button type="button" variant="outline" onClick={handleClearForm} data-testid="button-clear">
            Clear
          </Button>
          <Button 
            type="submit" 
            disabled={createMutation.isPending || updateMutation.isPending}
            data-testid="button-save"
          >
            {createMutation.isPending || updateMutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
