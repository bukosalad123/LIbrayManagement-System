import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { insertAuthorSchema, type Author, type InsertAuthor } from "@shared/schema";

interface AuthorFormProps {
  author?: Author | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function AuthorForm({ author, onSuccess, onCancel }: AuthorFormProps) {
  const { toast } = useToast();
  const isEditing = !!author;

  const form = useForm<InsertAuthor>({
    resolver: zodResolver(insertAuthorSchema),
    defaultValues: {
      name: author?.name || "",
      email: author?.email || "",
    },
  });

  const createMutation = useMutation({
    mutationFn: (data: InsertAuthor) => apiRequest("POST", "/api/authors", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/authors"] });
      toast({ title: "Success", description: "Author created successfully" });
      onSuccess();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to create author", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertAuthor) => 
      apiRequest("PUT", `/api/authors/${author!.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/authors"] });
      toast({ title: "Success", description: "Author updated successfully" });
      onSuccess();
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update author", variant: "destructive" });
    },
  });

  const onSubmit = (data: InsertAuthor) => {
    if (isEditing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  const handleClearForm = () => {
    form.reset({
      name: "",
      email: "",
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter author name" {...field} data-testid="input-author-name" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="email"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Email (Optional)</FormLabel>
              <FormControl>
                <Input type="email" placeholder="Enter email address" {...field} value={field.value || ""} data-testid="input-author-email" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-3">
          <Button type="button" variant="outline" onClick={onCancel} data-testid="button-cancel">
            Cancel
          </Button>
          <Button type="button" variant="outline" onClick={handleClearForm} data-testid="button-clear">
            Clear
          </Button>
          <Button 
            type="submit" 
            disabled={createMutation.isPending || updateMutation.isPending}
            data-testid="button-save"
          >
            {createMutation.isPending || updateMutation.isPending ? "Saving..." : isEditing ? "Update" : "Create"}
          </Button>
        </div>
      </form>
    </Form>
  );
}
