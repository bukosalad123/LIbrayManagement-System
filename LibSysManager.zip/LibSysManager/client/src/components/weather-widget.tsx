import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Sun, Cloud, CloudRain, CloudSnow, Wind } from "lucide-react";

interface WeatherData {
  main: {
    temp: number;
    humidity: number;
  };
  weather: Array<{
    main: string;
    description: string;
  }>;
  wind: {
    speed: number;
  };
  name: string;
}

export default function WeatherWidget() {
  const { data: weather, isLoading, error } = useQuery<WeatherData>({
    queryKey: ["/api/weather"],
    refetchInterval: 5 * 60 * 1000, // Refetch every 5 minutes
  });

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case 'clear':
        return Sun;
      case 'clouds':
        return Cloud;
      case 'rain':
        return CloudRain;
      case 'snow':
        return CloudSnow;
      default:
        return Sun;
    }
  };

  const WeatherIcon = weather?.weather[0] ? getWeatherIcon(weather.weather[0].main) : Sun;

  return (
    <Card data-testid="weather-widget">
      <div className="p-6 border-b border-border">
        <h3 className="text-lg font-semibold" data-testid="weather-title">Weather</h3>
        <p className="text-sm text-muted-foreground">Current conditions</p>
      </div>
      <CardContent className="p-6">
        {error ? (
          <div className="text-center text-muted-foreground">
            <p className="text-sm">Weather data unavailable</p>
            <p className="text-xs mt-1">Check API configuration</p>
          </div>
        ) : isLoading ? (
          <div className="text-center space-y-4">
            <Skeleton className="w-16 h-16 rounded-full mx-auto" />
            <Skeleton className="h-8 w-20 mx-auto" />
            <Skeleton className="h-4 w-24 mx-auto" />
          </div>
        ) : weather ? (
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <WeatherIcon className="text-blue-600 h-8 w-8" />
            </div>
            <p className="text-2xl font-bold" data-testid="weather-temperature">
              {Math.round(weather.main.temp)}°C
            </p>
            <p className="text-sm text-muted-foreground" data-testid="weather-condition">
              {weather.weather[0]?.description || 'Clear'}
            </p>
            <p className="text-xs text-muted-foreground mt-2" data-testid="weather-location">
              {weather.name}
            </p>
            
            <div className="mt-4 pt-4 border-t border-border">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Humidity</span>
                <span data-testid="weather-humidity">{weather.main.humidity}%</span>
              </div>
              <div className="flex justify-between text-sm mt-2">
                <span className="text-muted-foreground">Wind</span>
                <span data-testid="weather-wind">{Math.round(weather.wind.speed * 3.6)} km/h</span>
              </div>
            </div>
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}
