import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Students from "@/pages/students";
import Books from "@/pages/books";
import Authors from "@/pages/authors";
import Categories from "@/pages/categories";
import BorrowReturn from "@/pages/borrow-return";
import Librarians from "@/pages/librarians";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import { useIsMobile } from "@/hooks/use-mobile";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/students" component={Students} />
      <Route path="/books" component={Books} />
      <Route path="/authors" component={Authors} />
      <Route path="/categories" component={Categories} />
      <Route path="/borrow-return" component={BorrowReturn} />
      <Route path="/librarians" component={Librarians} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const isMobile = useIsMobile();

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <div className="flex h-screen overflow-hidden">
          {!isMobile && <Sidebar />}
          <div className="flex-1 flex flex-col overflow-hidden">
            {isMobile && <MobileHeader />}
            <main className="flex-1 overflow-auto">
              <Router />
            </main>
          </div>
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
