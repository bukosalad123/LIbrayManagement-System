import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, Edit, Trash2, Search, Bus } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import LibrarianForm from "@/components/forms/librarian-form";
import type { LibrarianWithType } from "@shared/schema";

export default function Librarians() {
  const [searchTerm, setSearchTerm] = useState("");
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingLibrarian, setEditingLibrarian] = useState<LibrarianWithType | null>(null);
  const { toast } = useToast();

  const { data: librarians, isLoading } = useQuery<LibrarianWithType[]>({
    queryKey: ["/api/librarians"],
  });

  const deleteLibrarianMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/librarians/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/librarians"] });
      toast({ title: "Success", description: "Librarian deleted successfully" });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete librarian", variant: "destructive" });
    },
  });

  const filteredLibrarians = librarians?.filter(librarian =>
    librarian.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    librarian.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    librarian.type.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this librarian?")) {
      deleteLibrarianMutation.mutate(id);
    }
  };

  return (
    <div className="p-6 space-y-6" data-testid="librarians-page">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold" data-testid="page-title">Librarians</h2>
          <p className="text-muted-foreground mt-1">Manage librarian accounts and access</p>
        </div>
        
        <Dialog open={isAddModalOpen} onOpenChange={setIsAddModalOpen}>
          <DialogTrigger asChild>
            <Button className="mt-4 sm:mt-0" data-testid="button-add-librarian">
              <Plus className="mr-2 h-4 w-4" />
              Add Librarian
            </Button>
          </DialogTrigger>
          <DialogContent data-testid="add-librarian-modal">
            <DialogHeader>
              <DialogTitle>Add Librarian</DialogTitle>
            </DialogHeader>
            <LibrarianForm 
              onSuccess={() => setIsAddModalOpen(false)}
              onCancel={() => setIsAddModalOpen(false)}
            />
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search librarians..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
              data-testid="input-search-librarians"
            />
          </div>
        </CardContent>
      </Card>

      {/* Librarians Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredLibrarians.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      {searchTerm ? "No librarians found matching your search." : "No librarians registered yet."}
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredLibrarians.map((librarian) => (
                    <TableRow key={librarian.id} data-testid={`librarian-row-${librarian.id}`}>
                      <TableCell className="font-medium" data-testid={`librarian-name-${librarian.id}`}>
                        <div className="flex items-center">
                          <Bus className="mr-2 h-4 w-4 text-muted-foreground" />
                          {librarian.name}
                        </div>
                      </TableCell>
                      <TableCell data-testid={`librarian-email-${librarian.id}`}>
                        {librarian.email}
                      </TableCell>
                      <TableCell data-testid={`librarian-type-${librarian.id}`}>
                        <Badge variant="outline">{librarian.type.name}</Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-green-100 text-green-800" data-testid={`librarian-status-${librarian.id}`}>
                          Active
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Dialog open={editingLibrarian?.id === librarian.id} onOpenChange={(open) => !open && setEditingLibrarian(null)}>
                            <DialogTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => setEditingLibrarian(librarian)}
                                data-testid={`button-edit-librarian-${librarian.id}`}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Edit Librarian</DialogTitle>
                              </DialogHeader>
                              <LibrarianForm 
                                librarian={editingLibrarian}
                                onSuccess={() => setEditingLibrarian(null)}
                                onCancel={() => setEditingLibrarian(null)}
                              />
                            </DialogContent>
                          </Dialog>
                          
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => handleDelete(librarian.id)}
                            disabled={deleteLibrarianMutation.isPending}
                            data-testid={`button-delete-librarian-${librarian.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
