import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import WeatherWidget from "@/components/weather-widget";
import { Book, Users, HandIcon, Undo, ArrowUp } from "lucide-react";

interface DashboardStats {
  totalBooks: number;
  totalStudents: number;
  borrowedBooks: number;
  returnedBooks: number;
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const statsCards = [
    {
      title: "Total Books",
      value: stats?.totalBooks || 0,
      icon: Book,
      color: "blue",
      trend: "+12% from last month",
    },
    {
      title: "Total Students", 
      value: stats?.totalStudents || 0,
      icon: Users,
      color: "green",
      trend: "+8% from last month",
    },
    {
      title: "Borrowed Books",
      value: stats?.borrowedBooks || 0,
      icon: HandIcon,
      color: "amber",
      trend: "+5% from last week",
    },
    {
      title: "Returned Books",
      value: stats?.returnedBooks || 0,
      icon: Undo,
      color: "purple",
      trend: "+15% from last week",
    },
  ];

  const colorMap = {
    blue: "bg-blue-100 text-blue-600",
    green: "bg-green-100 text-green-600", 
    amber: "bg-amber-100 text-amber-600",
    purple: "bg-purple-100 text-purple-600",
  };

  return (
    <div className="p-6 space-y-6" data-testid="dashboard-page">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold" data-testid="page-title">Dashboard</h2>
          <p className="text-muted-foreground mt-1">Welcome to the Library Management System</p>
        </div>
        <div className="mt-4 sm:mt-0">
          <span className="text-sm text-muted-foreground" data-testid="current-date">
            {new Date().toLocaleDateString('en-US', { 
              year: 'numeric', 
              month: 'long', 
              day: 'numeric' 
            })}
          </span>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {statsCards.map((card, index) => {
          const Icon = card.icon;
          
          return (
            <Card key={card.title} className="hover:shadow-lg transition-shadow" data-testid={`stat-card-${index}`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                    {isLoading ? (
                      <Skeleton className="h-8 w-16 mt-1" />
                    ) : (
                      <p className="text-2xl font-bold" data-testid={`stat-value-${index}`}>
                        {card.value.toLocaleString()}
                      </p>
                    )}
                    <p className="text-xs text-green-600 flex items-center mt-1">
                      <ArrowUp className="mr-1 h-3 w-3" />
                      {card.trend}
                    </p>
                  </div>
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${colorMap[card.color as keyof typeof colorMap]}`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Activity */}
        <div className="lg:col-span-2">
          <Card>
            <div className="p-6 border-b border-border">
              <h3 className="text-lg font-semibold" data-testid="recent-activity-title">Recent Activity</h3>
            </div>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                    <Book className="text-primary-foreground h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">No recent activity</p>
                    <p className="text-xs text-muted-foreground">Start borrowing and returning books to see activity</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Weather Widget */}
        <WeatherWidget />
      </div>
    </div>
  );
}
