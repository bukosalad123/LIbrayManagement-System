import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { HandIcon, Undo, Calendar, User, Book } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { BorrowedBookWithRelations, Student, BookWithRelations, LibrarianWithType } from "@shared/schema";

interface BorrowFormData {
  studentId: string;
  bookId: string;
  librarianId: string;
  dueDate: string;
}

interface ReturnFormData {
  borrowId: string;
  dateReturned: string;
  condition: string;
  notes: string;
}

export default function BorrowReturn() {
  const [borrowForm, setBorrowForm] = useState<BorrowFormData>({
    studentId: "",
    bookId: "",
    librarianId: "",
    dueDate: "",
  });
  
  const [returnForm, setReturnForm] = useState<ReturnFormData>({
    borrowId: "",
    dateReturned: new Date().toISOString().split('T')[0],
    condition: "good",
    notes: "",
  });

  const { toast } = useToast();

  // Fetch data
  const { data: borrowedBooks, isLoading: loadingBorrowedBooks } = useQuery<BorrowedBookWithRelations[]>({
    queryKey: ["/api/borrowed-books"],
  });

  const { data: students } = useQuery<Student[]>({
    queryKey: ["/api/students"],
  });

  const { data: books } = useQuery<BookWithRelations[]>({
    queryKey: ["/api/books"],
  });

  const { data: librarians } = useQuery<LibrarianWithType[]>({
    queryKey: ["/api/librarians"],
  });

  // Filter available books and active borrowed books
  const availableBooks = books?.filter(book => book.status === "available") || [];
  const activeBorrowedBooks = borrowedBooks?.filter(book => !book.dateReturned) || [];

  // Mutations
  const borrowBookMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/borrowed-books", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/borrowed-books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Success", description: "Book borrowed successfully" });
      setBorrowForm({
        studentId: "",
        bookId: "",
        librarianId: "",
        dueDate: "",
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to borrow book", variant: "destructive" });
    },
  });

  const returnBookMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => 
      apiRequest("PUT", `/api/borrowed-books/${id}/return`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/borrowed-books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
      toast({ title: "Success", description: "Book returned successfully" });
      setReturnForm({
        borrowId: "",
        dateReturned: new Date().toISOString().split('T')[0],
        condition: "good",
        notes: "",
      });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to return book", variant: "destructive" });
    },
  });

  const handleBorrowSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!borrowForm.studentId || !borrowForm.bookId || !borrowForm.librarianId || !borrowForm.dueDate) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    borrowBookMutation.mutate({
      studentId: borrowForm.studentId,
      bookId: borrowForm.bookId,
      librarianId: borrowForm.librarianId,
      dateBorrowed: new Date().toISOString().split('T')[0],
      dueDate: borrowForm.dueDate,
    });
  };

  const handleReturnSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!returnForm.borrowId || !returnForm.dateReturned) {
      toast({ title: "Error", description: "Please fill in all required fields", variant: "destructive" });
      return;
    }

    returnBookMutation.mutate({
      id: returnForm.borrowId,
      data: {
        dateReturned: returnForm.dateReturned,
        condition: returnForm.condition,
        notes: returnForm.notes,
      },
    });
  };

  const handleQuickReturn = (borrowId: string) => {
    returnBookMutation.mutate({
      id: borrowId,
      data: {
        dateReturned: new Date().toISOString().split('T')[0],
        condition: "good",
        notes: "",
      },
    });
  };

  const getStatusBadge = (book: BorrowedBookWithRelations) => {
    const dueDate = new Date(book.dueDate);
    const today = new Date();
    const isOverdue = dueDate < today && !book.dateReturned;
    
    if (book.dateReturned) {
      return <Badge variant="secondary" className="bg-green-100 text-green-800">Returned</Badge>;
    } else if (isOverdue) {
      return <Badge variant="destructive">Overdue</Badge>;
    } else {
      return <Badge variant="secondary" className="bg-amber-100 text-amber-800">Active</Badge>;
    }
  };

  return (
    <div className="p-6 space-y-6" data-testid="borrow-return-page">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h2 className="text-2xl font-bold" data-testid="page-title">Borrow/Return Books</h2>
          <p className="text-muted-foreground mt-1">Manage book borrowing and returns</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Borrow Book Form */}
        <Card>
          <div className="p-6 border-b border-border">
            <h3 className="text-lg font-semibold flex items-center" data-testid="borrow-form-title">
              <HandIcon className="mr-2 h-5 w-5" />
              Borrow Book
            </h3>
          </div>
          <CardContent className="p-6">
            <form onSubmit={handleBorrowSubmit} className="space-y-4">
              <div>
                <Label htmlFor="student-select">Student</Label>
                <Select 
                  value={borrowForm.studentId} 
                  onValueChange={(value) => setBorrowForm(prev => ({ ...prev, studentId: value }))}
                >
                  <SelectTrigger data-testid="select-borrow-student">
                    <SelectValue placeholder="Select student" />
                  </SelectTrigger>
                  <SelectContent>
                    {students?.map((student) => (
                      <SelectItem key={student.id} value={student.id}>
                        {student.name} ({student.studentId})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="book-select">Book</Label>
                <Select 
                  value={borrowForm.bookId} 
                  onValueChange={(value) => setBorrowForm(prev => ({ ...prev, bookId: value }))}
                >
                  <SelectTrigger data-testid="select-borrow-book">
                    <SelectValue placeholder="Select book" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableBooks?.map((book) => (
                      <SelectItem key={book.id} value={book.id}>
                        {book.title} - {book.author.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="librarian-select">Librarian</Label>
                <Select 
                  value={borrowForm.librarianId} 
                  onValueChange={(value) => setBorrowForm(prev => ({ ...prev, librarianId: value }))}
                >
                  <SelectTrigger data-testid="select-borrow-librarian">
                    <SelectValue placeholder="Select librarian" />
                  </SelectTrigger>
                  <SelectContent>
                    {librarians?.map((librarian) => (
                      <SelectItem key={librarian.id} value={librarian.id}>
                        {librarian.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="due-date">Due Date</Label>
                <Input
                  id="due-date"
                  type="date"
                  value={borrowForm.dueDate}
                  onChange={(e) => setBorrowForm(prev => ({ ...prev, dueDate: e.target.value }))}
                  min={new Date().toISOString().split('T')[0]}
                  data-testid="input-due-date"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full" 
                disabled={borrowBookMutation.isPending}
                data-testid="button-borrow-book"
              >
                <HandIcon className="mr-2 h-4 w-4" />
                {borrowBookMutation.isPending ? "Processing..." : "Borrow Book"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Return Book Form */}
        <Card>
          <div className="p-6 border-b border-border">
            <h3 className="text-lg font-semibold flex items-center" data-testid="return-form-title">
              <Undo className="mr-2 h-5 w-5" />
              Return Book
            </h3>
          </div>
          <CardContent className="p-6">
            <form onSubmit={handleReturnSubmit} className="space-y-4">
              <div>
                <Label htmlFor="borrow-record-select">Borrowed Book</Label>
                <Select 
                  value={returnForm.borrowId} 
                  onValueChange={(value) => setReturnForm(prev => ({ ...prev, borrowId: value }))}
                >
                  <SelectTrigger data-testid="select-return-book">
                    <SelectValue placeholder="Select borrowed book" />
                  </SelectTrigger>
                  <SelectContent>
                    {activeBorrowedBooks?.map((record) => (
                      <SelectItem key={record.id} value={record.id}>
                        {record.book.title} - {record.student.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="return-date">Return Date</Label>
                <Input
                  id="return-date"
                  type="date"
                  value={returnForm.dateReturned}
                  onChange={(e) => setReturnForm(prev => ({ ...prev, dateReturned: e.target.value }))}
                  max={new Date().toISOString().split('T')[0]}
                  data-testid="input-return-date"
                />
              </div>

              <div>
                <Label htmlFor="condition-select">Condition</Label>
                <Select 
                  value={returnForm.condition} 
                  onValueChange={(value) => setReturnForm(prev => ({ ...prev, condition: value }))}
                >
                  <SelectTrigger data-testid="select-book-condition">
                    <SelectValue placeholder="Select condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="damaged">Damaged</SelectItem>
                    <SelectItem value="lost">Lost</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  placeholder="Additional notes..."
                  value={returnForm.notes}
                  onChange={(e) => setReturnForm(prev => ({ ...prev, notes: e.target.value }))}
                  rows={3}
                  data-testid="textarea-return-notes"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full bg-green-600 hover:bg-green-700" 
                disabled={returnBookMutation.isPending}
                data-testid="button-return-book"
              >
                <Undo className="mr-2 h-4 w-4" />
                {returnBookMutation.isPending ? "Processing..." : "Return Book"}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Current Borrowed Books */}
      <Card>
        <div className="p-6 border-b border-border">
          <h3 className="text-lg font-semibold" data-testid="borrowed-books-title">Currently Borrowed Books</h3>
        </div>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Book</TableHead>
                  <TableHead>Author</TableHead>
                  <TableHead>Borrowed Date</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingBorrowedBooks ? (
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    </TableRow>
                  ))
                ) : activeBorrowedBooks.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No books currently borrowed.
                    </TableCell>
                  </TableRow>
                ) : (
                  activeBorrowedBooks.map((record) => (
                    <TableRow key={record.id} data-testid={`borrowed-book-row-${record.id}`}>
                      <TableCell data-testid={`borrowed-student-${record.id}`}>
                        {record.student.name}
                      </TableCell>
                      <TableCell data-testid={`borrowed-book-title-${record.id}`}>
                        {record.book.title}
                      </TableCell>
                      <TableCell data-testid={`borrowed-book-author-${record.id}`}>
                        {record.book.author.name}
                      </TableCell>
                      <TableCell data-testid={`borrowed-date-${record.id}`}>
                        {new Date(record.dateBorrowed).toLocaleDateString()}
                      </TableCell>
                      <TableCell data-testid={`due-date-${record.id}`}>
                        {new Date(record.dueDate).toLocaleDateString()}
                      </TableCell>
                      <TableCell data-testid={`borrowed-status-${record.id}`}>
                        {getStatusBadge(record)}
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleQuickReturn(record.id)}
                          disabled={returnBookMutation.isPending}
                          className="text-green-600 hover:text-green-800"
                          data-testid={`button-quick-return-${record.id}`}
                        >
                          <Undo className="mr-1 h-4 w-4" />
                          Return
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
